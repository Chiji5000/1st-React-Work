import React from "react";
import "./testimonials.css";
import IMG1 from "../../assets/download2.jpeg";
import IMG2 from "../../assets/image2.jpg";
import IMG3 from "../../assets/image3.jpg";
import IMG4 from "../../assets/image4.jpg";
// import Swiper core and required modules
import { Pagination } from "swiper/modules";

import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";

const Testimonials = () => {
  return (
    <section id="testimonials">
      <h5>Review From Clients</h5>
      <h2>Testimonials</h2>

      <Swiper
        className="container testimonials__container"
        modules={[Pagination]}
        spaceBetween={40}
        slidesPerView={1}
        pagination={{ clickable: true }}
      >
        <SwiperSlide className="testimonial">
          <div className="client__avatar">
            <img src={IMG1} alt="" />
          </div>
          <h5 className="client__name">Person1</h5>
          <small className="client__review">
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Blanditiis
            obcaecati sed a mollitia? Cupiditate atque at tempora vel placeat
            explicabo!
          </small>
        </SwiperSlide>
        <SwiperSlide className="testimonial">
          <div className="client__avatar">
            <img src={IMG2} alt="" />
          </div>
          <h5 className="client__name">Person2</h5>
          <small className="client__review">
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Blanditiis
            obcaecati sed a mollitia? Cupiditate atque at tempora vel placeat
            explicabo!. Lorem ipsum dolor sit, amet consectetur adipisicing
            elit. Aut, perferendis?
          </small>
        </SwiperSlide>
        <SwiperSlide className="testimonial">
          <div className="client__avatar">
            <img src={IMG3} alt="" />
          </div>
          <h5 className="client__name">Person3</h5>
          <small className="client__review">
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Blanditiis
            obcaecati sed a mollitia? Cupiditate atque at tempora vel placeat
            explicabo!. Lorem ipsum dolor sit amet consectetur adipisicing elit.
            Dolorem atque, autem laudantium debitis quia cum!
          </small>
        </SwiperSlide>
        <SwiperSlide className="testimonial">
          <div className="client__avatar">
            <img src={IMG4} alt="" />
          </div>
          <h5 className="client__name">Person4</h5>
          <small className="client__review">
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Blanditiis
            obcaecati sed a mollitia? Cupiditate atque at tempora vel placeat
            explicabo!. Lorem ipsum dolor sit amet.
          </small>
        </SwiperSlide>
      </Swiper>
    </section>
  );
};

export default Testimonials;
